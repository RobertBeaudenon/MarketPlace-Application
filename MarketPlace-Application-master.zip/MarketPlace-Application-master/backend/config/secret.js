//All our config will be centralized in that file so that we can modify one place and we are exporting it to make it available where we need it
//chat app is the db name
module.exports = {
  url: 'mongodb://localhost:27017/chatapp',
  secret: 'myjsonsecret',
  AWS_SECRET_ACCESS: 'wAsah834yUpzvc6Dg+0iUjtg7Gjs4SNae5qQit+b',
  AWS_ACCESS_KEY: 'AKIAXTWJDTP4DIMCJSWO',
  S3_BUCKET: 'hlpr-marketplace-images',
  TEST: 'jdkbejkcnxejkcnx'
};
